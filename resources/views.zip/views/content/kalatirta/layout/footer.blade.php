<footer id="footer">
    <div class="container footer-content">
        <div class="copyright">
            <p>Kalatirta &copy; 2023. BBWS Serayu Opak, Ditjen Sumber Daya Air - Kementerian PUPR.</p>
        </div>
    </div>
</footer>