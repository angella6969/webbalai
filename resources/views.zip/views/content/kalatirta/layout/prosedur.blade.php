<section id="prosedur" class="section-content section-bg">
    <div class="container animated fadeIn">
        <div class="section-title">
            <span>Prosedur</span>
            <h2><strong>Prosedur</strong></h2>
        </div>
        <div class="section-cap">"Tata Cara Penggunaan Kalatirta"</div>
        <div class="section-row clearfix">
            <img src="{{ asset('kalatirta') }}/images/sop-kalatirta.jpg" class="animated fadeIn"
                alt="" width="200">
            <iframe width="560" height="315"
                src="https://www.youtube.com/embed/YSJTEl0VIcQ?si=6rwzkCPLpDJK9Cj2"
                title="YouTube video player" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen></iframe>
        </div>
    </div>
</section>