<section id="topbar">
    <div class="container section-info time">
        <span id="time"></span>
    </div>
    <div class="container section-info social-links">
        <svg class="icon">
            <use xlink:href="#facebook"></use>
        </svg>
        <svg class="icon">
            <use xlink:href="#instagram"></use>
        </svg>
        <svg class="icon">
            <use xlink:href="#twitterx"></use>
        </svg>
        <svg class="icon">
            <use xlink:href="#youtube"></use>
        </svg>
        <svg class="icon">
            <use xlink:href="#tiktok"></use>
        </svg>
    </div>
</section>