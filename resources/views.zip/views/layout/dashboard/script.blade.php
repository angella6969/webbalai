<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>
<script src="https://code.jquery.com/jquery-3.7.0.slim.min.js"
    integrity="sha256-tG5mcZUtJsZvyKAxYLVXrmjKBVLd6VpVccqz/r4ypFE=" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.js"
    integrity="sha512-OmBbzhZ6lgh87tQFDVBHtwfi6MS9raGmNvUNTjDIBb/cgv707v9OuBVpsN6tVVTLOehRFns+o14Nd0/If0lE/A=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    feather.replace()
</script>
{{-- <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
{{-- <script src="{{ asset('src') }}/assets/libs/jquery/dist/jquery.min.js"></script>
<script src="{{ asset('src') }}/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="{{ asset('src') }}/assets/js/sidebarmenu.js"></script>
<script src="{{ asset('src') }}/assets/js/app.min.js"></script>
<script src="{{ asset('src') }}/assets/libs/apexcharts/dist/apexcharts.min.js"></script>
<script src="{{ asset('src') }}/assets/libs/simplebar/dist/simplebar.js"></script>
<script src="{{ asset('src') }}/assets/js/dashboard.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
    integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>