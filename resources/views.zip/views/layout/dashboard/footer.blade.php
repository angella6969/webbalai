<footer>
  <div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">BBWS Serayu Opak </p>
  </div>
</footer>