<div class="separator">
    <br>
    <p class="d-flex justify-content-center">Dokumen Pendukunng</p>
    <div class="line"></div>
</div>