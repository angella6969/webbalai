<section class="breadcrumbs">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h2>{{ $judul }}</h2>
            <ol>
                <li><a style="color: var(--bs-light-text)" href="/">{{ $posisi1 }}</a></li>
                <li><a style="color: var(--bs-light-text)" href="{{ $link }}">{{ $posisi2 }}</a></li>
            </ol>
        </div>
    </div>
</section>


{{-- <section class="breadcrumbs">
    <div class="container"><br>
        <div class="row align-items-center ">
            <div class="col-md-8 text-left">
                <span class="tob-sub-title text-color-light d-block">Informasi</span>
                <h1 class="font-weight-bold text-color-light">Infrastruktur</h1>
            </div>
            <div class="col-md-4">
                <ul class="breadcrumb justify-content-start text-color-light justify-content-md-end">
                    <li><a style="color: black" href="/">Beranda</a> / <a href="" style="color: black"
                            class="active"><strong>Infrastruktur</strong></a></li>
                    <li class="active"> Profil</li>
                </ul>
            </div>
        </div>
    </div>
</section> --}}
